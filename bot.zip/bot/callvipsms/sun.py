import asyncio
import html
import json
import logging
import os
import random
import sqlite3
import subprocess
import threading
import time
import gc
import signal
from datetime import datetime
from functools import wraps
from typing import Optional
import phonenumbers
import psutil
import pytz
from phonenumbers import carrier, geocoder
import atexit
from aiogram import Bot, Dispatcher, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError, TelegramForbiddenError
from aiogram.filters import Command
from aiogram.types import Message, User, BotCommand, InlineKeyboardButton, InlineKeyboardMarkup

MA_TOKEN_BOT = os.getenv('BOT_TOKEN', "7657683464:AAFRJkE2iuClkecQTZgwpBj8G9LB8oAsnyU")

ID_ADMIN_MAC_DINH = "7497594902"
TEN_ADMIN_MAC_DINH = "hoang nam"
ID_NHOM_CHO_PHEP = -1003405933400
THU_MUC_DU_LIEU = "./data"
os.makedirs(THU_MUC_DU_LIEU, exist_ok=True)
logging.disable(logging.NOTSET)  # bật lại toàn bộ log

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)   # mức chi tiết nhất
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)

DUONG_DAN_DB = os.path.join(THU_MUC_DU_LIEU, "bot_data.db")

SCRIPT_SMS_DIRECT = ["vip_0.py"]

SCRIPT_CALL_DIRECT = ["vip1_min.py"]

SCRIPT_SPAM_DIRECT = ["spam_0.py"]

SCRIPT_VIP_DIRECT = ["sms_1.py"]

SCRIPT_FREE = ["spam_0.py"]

SCRIPT_CACHE = {}
SCRIPT_CACHE_TIME = {}

def cleanup_old_cache():
    current_time = time.time()
    keys_to_remove = []

    for key, timestamp in SCRIPT_CACHE_TIME.items():
        if current_time - timestamp > 600:  # 10 phút
            keys_to_remove.append(key)

    for key in keys_to_remove:
        SCRIPT_CACHE.pop(key, None)
        SCRIPT_CACHE_TIME.pop(key, None)

def get_available_scripts(script_list, cache_key):
    current_time = time.time()

    if len(SCRIPT_CACHE) > 20:
        cleanup_old_cache()

    if (cache_key in SCRIPT_CACHE and
        cache_key in SCRIPT_CACHE_TIME and
        current_time - SCRIPT_CACHE_TIME[cache_key] < 600):
        return SCRIPT_CACHE[cache_key]

    available = [s for s in script_list if os.path.exists(s)]
    SCRIPT_CACHE[cache_key] = available
    SCRIPT_CACHE_TIME[cache_key] = current_time
    return available

TIMEOUT_NGAN = 180
TIMEOUT_TRUNG_BINH = 360
TIMEOUT_MO_RONG = 3600

# Khởi tạo bot
try:
    bot = Bot(
        token=MA_TOKEN_BOT,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML,
            link_preview_is_disabled=True
        )
    )
except Exception as e:
    logger.error(f"Lỗi khởi tạo bot: {e}")
    raise

def tao_ket_noi_db():
    try:
        conn = sqlite3.connect(DUONG_DAN_DB, check_same_thread=False, timeout=8.0)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error:
        os.makedirs(os.path.dirname(DUONG_DAN_DB), exist_ok=True)
        conn = sqlite3.connect(DUONG_DAN_DB)
        conn.row_factory = sqlite3.Row
        return conn

# ============ CÁC LỚP QUẢN LÝ CACHE ============
class QuanLyQuyenCache:
    def __init__(self):
        self.cache = {}
        self.kich_thuoc_toi_da = 500  # Tăng cache size

    def lay_quyen(self, user_id):
        if user_id in self.cache:
            entry = self.cache[user_id]
            if time.time() - entry['thoi_gian_luu'] < 3600:  # Tăng cache time lên 1 giờ
                return entry['quyen']
            else:
                del self.cache[user_id]
        return None

    def dat_quyen(self, user_id, quyen):
        if len(self.cache) >= self.kich_thuoc_toi_da:
            # Xóa batch cũ hơn thay vì xóa random
            now = time.time()
            old_keys = [k for k, v in self.cache.items() if now - v['thoi_gian_luu'] > 1800]
            for key in old_keys[:100]:
                self.cache.pop(key, None)
        self.cache[user_id] = {'quyen': quyen, 'thoi_gian_luu': time.time()}

class QuanLyCooldown:
    def __init__(self):
        self.cache = {}
        self._lock = threading.RLock()

    def kiem_tra_cooldown(self, user_id, lenh):
        key = f"{lenh}:{user_id}"
        thoi_gian_hien_tai = time.time()

        if key not in self.cache:
            return False, 0, None

        with self._lock:
            lan_su_dung_cuoi = self.cache[key]
            # Inline cooldown calculation để giảm function calls
            quyen = lay_cap_do_quyen_nguoi_dung(user_id)
            thoi_gian_cooldown = COOLDOWN_LENH.get(lenh, {}).get(quyen, 60)

            if thoi_gian_hien_tai - lan_su_dung_cuoi < thoi_gian_cooldown:
                thoi_gian_con_lai = thoi_gian_cooldown - (thoi_gian_hien_tai - lan_su_dung_cuoi)
                return True, max(0, thoi_gian_con_lai), "command_specific"
        return False, 0, None

    def dat_cooldown(self, user_id, lenh):
        key = f"{lenh}:{user_id}"
        with self._lock:
            self.cache[key] = time.time()

FULL_STATUS = {}
FULL_LOCK = threading.Lock()

def dat_trang_thai_full(user_id, so_dien_thoai):
    with FULL_LOCK:
        key = f"{user_id}:{so_dien_thoai}"
        FULL_STATUS[key] = time.time() + 24 * 3600

def xoa_trang_thai_full(user_id, so_dien_thoai):
    with FULL_LOCK:
        key = f"{user_id}:{so_dien_thoai}"
        FULL_STATUS.pop(key, None)

def kiem_tra_so_full(user_id, so_dien_thoai):
    with FULL_LOCK:
        key = f"{user_id}:{so_dien_thoai}"
        if key in FULL_STATUS and FULL_STATUS[key] > time.time():
            return True
        FULL_STATUS.pop(key, None)
        return False

quan_ly_quyen_cache = QuanLyQuyenCache()
quan_ly_cooldown = QuanLyCooldown()

def chay_tien_trinh_nen_sync(command, timeout=None, user_id=None):
    """Chạy tiến trình nền đồng bộ với tracking tốt hơn"""
    try:
        if not command or not isinstance(command, str):
            return False, None, None
        command = command.strip()
        if len(command) > 1000:
            return False, None, None

        # Sử dụng setsid để tránh orphaned processes
        full_command = f"setsid {command} > /dev/null 2>&1 & echo $!"

        result = subprocess.run(
            full_command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=15  # Tăng timeout tạo process
        )

        if result.returncode == 0 and result.stdout.strip():
            pid = int(result.stdout.strip())

            # Kiểm tra process có tồn tại và track nó
            time.sleep(0.5)  # Chờ lâu hơn để process khởi động ổn định
            try:
                proc = psutil.Process(pid)
                if proc.is_running():
                    # Log để tracking
                    logger.info(f"Tạo process PID {pid} cho user {user_id}: {command[:50]}...")

                    # Đặt process group để dễ cleanup
                    try:
                        os.setpgid(pid, pid)
                    except (OSError, ProcessLookupError):
                        pass  # Process có thể đã set pgid

                    return True, pid, None
            except psutil.NoSuchProcess:
                logger.warning(f"Process {pid} đã thoát ngay sau khi tạo")

        return False, None, None
    except Exception as e:
        logger.error(f"Lỗi chay_tien_trinh_nen_sync: {e}")
        return False, None, None

def dem_tien_trinh_dong_bo(user_id=None):
    """Đếm tiến trình"""
    try:
        count = 0
        for proc in psutil.process_iter(['cmdline']):
            try:
                cmdline = ' '.join(proc.info['cmdline'] or [])
                if 'python' in cmdline and any(script in cmdline for script in ['spam_', 'sms_', 'vip_', 'call']):
                    if user_id is None or str(user_id) in cmdline:
                        count += 1
            except:
                continue
        return count
    except:
        return 0

def tat_tien_trinh_dong_bo(pattern):
    killed_count = 0
    try:
        processes_to_kill = []
        process_families = {}  # Track process families để kill đệ quy

        for proc in psutil.process_iter(['pid', 'ppid', 'cmdline', 'name', 'status', 'create_time']):
            try:
                proc_info = proc.info
                if not proc_info['cmdline']:
                    continue

                cmdline = ' '.join(proc_info['cmdline'])
                proc_name = proc_info.get('name', '')
                proc_status = proc_info.get('status', '')

                # Kiểm tra zombie process
                if proc_status == psutil.STATUS_ZOMBIE:
                    processes_to_kill.append(proc)
                    continue

                # Kiểm tra python processes liên quan - mở rộng pattern matching
                is_target_process = (
                    ('python' in proc_name.lower() or 'python' in cmdline.lower()) and
                    any(script in cmdline for script in [
                        'spam_', 'sms_', 'vip_', 'call', 'lenh', 'tcp.py', 'tt.py', 
                        'ngl.py', 'pro24h.py', 'vip11122.py', 'mlm.py', 'vip1_min.py', 
                        'master222.py'
                    ])
                )
                if proc_info.get('create_time'):
                    process_age = time.time() - proc_info['create_time']
                    if process_age > 21600 and is_target_process:  # 6 giờ = 21600 giây
                        logger.warning(f"Phát hiện process cũ {proc_info['pid']}: {process_age/3600:.1f} giờ - {cmdline[:100]}")

                if not is_target_process:
                    continue

                should_kill = False
                if pattern == "python.*lenh":
                    should_kill = True
                elif "lenh.*" in pattern:
                    parts = pattern.split('.*')
                    if len(parts) >= 3:
                        user_id = parts[-1]
                        if user_id and user_id in cmdline:
                            should_kill = True
                else:
                    pattern_clean = pattern.replace('.*', '').replace('python3', 'python')
                    if pattern_clean in cmdline:
                        should_kill = True

                if should_kill:
                    processes_to_kill.append(proc)

                    # Thu thập process family để kill đệ quy
                    try:
                        children = proc.children(recursive=True)
                        process_families[proc.pid] = children
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass

            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        for proc in processes_to_kill:
            try:
                if proc.status() == psutil.STATUS_ZOMBIE:
                    # Xử lý zombie bằng cách kill parent
                    try:
                        parent = proc.parent()
                        if parent and parent.pid != 1:
                            parent.terminate()
                            parent.wait(timeout=2)
                    except:
                        pass
                    killed_count += 1
                    continue
                children = process_families.get(proc.pid, [])
                for child in children:
                    try:
                        if child.is_running():
                            child.terminate()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                time.sleep(0.5)
                for child in children:
                    try:
                        if child.is_running():
                            child.kill()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                proc.terminate()
                try:
                    proc.wait(timeout=8)  # Tăng từ 3s lên 8s
                    killed_count += 1
                except psutil.TimeoutExpired:
                    # Force kill nếu không terminate được
                    proc.kill()
                    try:
                        proc.wait(timeout=5)  # Tăng từ 2s lên 5s
                        killed_count += 1
                    except:
                        try:
                            os.kill(proc.pid, 9)
                            killed_count += 1
                        except:
                            pass
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                killed_count += 1
                continue
        if killed_count == 0:
            try:
                commands = []
                if 'lenh.*' in pattern and len(pattern.split('.*')) > 2:
                    user_id = pattern.split('.*')[-1]
                    commands = [
                        f"pkill -15 -f 'python.*{user_id}'",
                        f"pkill -9 -f 'python.*{user_id}'",
                        "pkill -9 -f 'spam_|sms_|vip_|call|tcp.py|tt.py|ngl.py|pro24h.py'"
                    ]
                else:
                    commands = [
                        "pkill -15 -f 'python.*lenh'",
                        "pkill -9 -f 'python.*lenh'", 
                        "pkill -9 -f 'spam_|sms_|vip_|call|tcp.py|tt.py|ngl.py|pro24h.py'"
                        # Thêm lệnh aggressive cleanup
                        "pkill -9 -f 'python3.*vip'",
                        "pkill -9 -f 'python.*pro24h'"
                    ]

                for cmd in commands:
                    try:
                        result = subprocess.run(cmd, shell=True, timeout=5, capture_output=True)
                        if result.returncode == 0:
                            killed_count += 1
                        time.sleep(0.2)  # Delay nhỏ giữa các lệnh
                    except:
                        continue

            except Exception:
                pass

        try:
            # Cleanup zombies mạnh hơn
            subprocess.run("ps aux | grep '<defunct>' | awk '{print $2}' | xargs -r kill -9 2>/dev/null || true",
                         shell=True, timeout=8, capture_output=True)

            subprocess.run("ps -eo pid,etime,cmd | grep python | awk '$2 ~ /^[0-9]+-/ || $2 ~ /^[0-6][0-9]:[0-5][0-9]:[0-5][0-9]/ {print $1}' | head -20 | xargs -r kill -9 2>/dev/null || true",
                         shell=True, timeout=10, capture_output=True)

            subprocess.run("find /tmp -name '*.py*' -mmin +60 -delete 2>/dev/null || true",
                         shell=True, timeout=10, capture_output=True)

            subprocess.run("find . -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null || true",
                         shell=True, timeout=10, capture_output=True)

            subprocess.run("sync", shell=True, timeout=3, capture_output=True)

        except Exception as e:
            logger.error(f"Lỗi enhanced cleanup: {e}")

    except Exception as e:
        logger.error(f"Lỗi tat_tien_trinh_dong_bo: {e}")
        return False

    logger.info(f"Đã dọn dẹp {killed_count} processes với pattern: {pattern}")
    return killed_count > 0

def khoi_tao_database():
    conn = None
    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admin (
                user_id TEXT PRIMARY KEY,
                name TEXT,
                role TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vip_lists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                list_name TEXT NOT NULL,
                phone_numbers TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                UNIQUE(user_id, list_name)
            )
        ''')
        conn.commit()
    except Exception as e:
        logger.error(f"Lỗi khi khởi tạo database: {e}")
    finally:
        if conn:
            try:
                conn.close()
            except Exception as e:
                logger.error(f"Lỗi khi đóng kết nối DB: {e}")

def khoi_tao_admin_mac_dinh():
    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM admin WHERE user_id = ?", (ID_ADMIN_MAC_DINH,))
        if not cursor.fetchone():
            cursor.execute(
                "INSERT INTO admin (user_id, name, role) VALUES (?, ?, ?)",
                (ID_ADMIN_MAC_DINH, TEN_ADMIN_MAC_DINH, 'admin')
            )
            conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Lỗi khi khởi tạo admin mặc định: {e}")

# ============ HỆ THỐNG PHÂN QUYỀN ============
def lay_cap_do_quyen_nguoi_dung(user_id):
    user_id = str(user_id)
    if user_id == ID_ADMIN_MAC_DINH:
        return 'admin'

    cached_quyen = quan_ly_quyen_cache.lay_quyen(user_id)
    if cached_quyen is not None:
        return cached_quyen

    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute("SELECT role FROM admin WHERE user_id = ? LIMIT 1", (user_id,))
        admin_result = cursor.fetchone()
        conn.close()

        if admin_result:
            quyen = admin_result['role']
        else:
            quyen = 'member'

        quan_ly_quyen_cache.dat_quyen(user_id, quyen)
        return quyen
    except Exception as e:
        logger.error(f"Lỗi khi lấy quyền người dùng {user_id}: {e}")
        quan_ly_quyen_cache.dat_quyen(user_id, 'member')
        return 'member'

def la_admin(user_id):
    return lay_cap_do_quyen_nguoi_dung(user_id) == 'admin'

def la_vip_vinh_vien(user_id):
    cap_do = lay_cap_do_quyen_nguoi_dung(user_id)
    return cap_do in ('admin', 'vip')

CACHE_SO_DIEN_THOAI = {}
KHOA_CACHE_SO_DIEN_THOAI = threading.Lock()

def la_so_dien_thoai_hop_le(so_dien_thoai):
    if not so_dien_thoai:
        return False

    with KHOA_CACHE_SO_DIEN_THOAI:
        if so_dien_thoai in CACHE_SO_DIEN_THOAI:
            return CACHE_SO_DIEN_THOAI[so_dien_thoai]

    try:
        if not so_dien_thoai.isdigit() or len(so_dien_thoai) not in [10, 11]:
            with KHOA_CACHE_SO_DIEN_THOAI:
                CACHE_SO_DIEN_THOAI[so_dien_thoai] = False
            return False

        so = phonenumbers.parse(so_dien_thoai, "VN")
        hop_le = phonenumbers.is_valid_number(so)

        with KHOA_CACHE_SO_DIEN_THOAI:
            CACHE_SO_DIEN_THOAI[so_dien_thoai] = hop_le
        return hop_le
    except Exception:
        with KHOA_CACHE_SO_DIEN_THOAI:
            CACHE_SO_DIEN_THOAI[so_dien_thoai] = False
        return False

def xac_thuc_so_voi_nha_mang(so_dien_thoai):
    try:
        if not so_dien_thoai or not isinstance(so_dien_thoai, str):
            return False, "𝑆𝑜̂́ điện thoại không hợp lệ"

        so_sach = ''.join(filter(str.isdigit, so_dien_thoai))

        if not la_so_dien_thoai_hop_le(so_sach):
            return False, "𝑆𝑜̂́ điện thoại không hợp lệ"

        so_da_phan_tich = phonenumbers.parse(so_sach, "VN")

        if not phonenumbers.is_valid_number(so_da_phan_tich):
            return False, "𝑆𝑜̂́ điện thoại không hợp lệ"

        try:
            ten_nha_mang = carrier.name_for_number(so_da_phan_tich, "vi")
        except ImportError:
            ten_nha_mang = get_carrier(so_sach)

        if not ten_nha_mang or ten_nha_mang == "Không rõ":
            ten_nha_mang = get_carrier(so_sach)

        return True, ten_nha_mang
    except phonenumbers.NumberParseException:
        return False, "𝑆𝑜̂́ không hợp lệ"
    except Exception:
        return False, "𝑆𝑜̂́ không hợp lệ"

# ============ GIỚI HẠN & COOLDOWN ============
# Tối ưu cooldown - giảm thời gian chờ để bot phản hồi nhanh hơn
COOLDOWN_LENH = {
    'xu_ly_ddos': {'admin': 60, 'vip': 180, 'member': 1800},
    'xu_ly_vip': {'admin': 90, 'vip': 180, 'member': 900},
    'xu_ly_spam': {'admin': 60, 'vip': 180, 'member': 180},
    'xu_ly_sms': {'admin': 60, 'vip': 180, 'member': 450},
    'xu_ly_call': {'admin': 30, 'vip': 180, 'member': 1800},
    'xu_ly_full': {'admin': 3600, 'vip': 3600, 'member': 3600},  # Giảm từ 7200->3600
    'xu_ly_tiktok': {'admin': 180, 'vip': 300, 'member': 900},
    'xu_ly_ngl': {'admin': 180, 'vip': 300, 'member': 900},
    'xu_ly_free': {'admin': 600, 'vip': 200, 'member': 300},  # 10 phút cho tất cả
}

def lay_gioi_han_so_dien_thoai(user_id):
    cap_do = lay_cap_do_quyen_nguoi_dung(user_id)
    gioi_han = {'admin': 50, 'vip': 50, 'member': 2}
    return gioi_han.get(cap_do, 2)

# ============ KHÓA LỆNH VÀ BẢO TRÌ ============
# Danh sách các lệnh đang bị khóa để bảo trì
LOCKED_COMMANDS = {"call"}

async def kiem_tra_lenh_bi_khoa(message: Message, ten_lenh: str) -> bool:
    """
    Kiểm tra xem lệnh có bị khóa không và gửi thông báo nếu bị khóa
    Returns True nếu lệnh bị khóa, False nếu không bị khóa
    """
    if ten_lenh in LOCKED_COMMANDS:
        await gui_phan_hoi(
            message,
            "🔒 Hệ thống đang được nâng cấp để mang đến trải nghiệm tốt hơn.\n"
            "Vui lòng sử dụng lệnh /free !\n\n"
            "Cảm ơn bạn đã kiên nhẫn chờ đợi!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return True
    return False

# ============ CÁC HÀM TIỆN ÍCH ============
def lay_thoi_gian_vn():
    """Lấy thời gian Việt Nam"""
    try:
        mui_gio_vn = pytz.timezone("Asia/Ho_Chi_Minh")
        hien_tai = datetime.now(mui_gio_vn)
        return hien_tai.strftime("%H:%M:%S"), hien_tai.strftime("%d/%m/%Y")
    except Exception as e:
        logger.error(f"Lỗi lấy giờ Việt Nam: {e}")
        hien_tai = datetime.now()
        return hien_tai.strftime("%H:%M:%S"), hien_tai.strftime("%d/%m/%Y")

def escape_html(text):
    if text is None:
        return ""
    return html.escape(str(text))

def dinh_dang_thoi_gian_cooldown(giay):
    """Định dạng thời gian cooldown"""
    if giay <= 0:
        return "0 𝑔𝑖𝑎̂𝑦"
    if giay < 60:
        return f"{int(giay)} 𝑔𝑖𝑎̂𝑦"
    phut = int(giay // 60)
    giay_con_lai = int(giay % 60)
    if giay_con_lai == 0:
        return f"{phut} 𝑝ℎ𝑢́𝑡"
    else:
        return f"{phut} 𝑝ℎ𝑢́𝑡 {giay_con_lai} 𝑔𝑖𝑎̂𝑦"

def dinh_dang_lien_ket_nguoi_dung(user):
    """Định dạng liên kết người dùng"""
    try:
        if not user:
            return "Người dùng không rõ"
        user_id = user.id
        ten_day_du = user.full_name
        if not user_id:
            return escape_html(ten_day_du or "Người dùng không rõ")
        if ten_day_du:
            return f'<a href="tg://user?id={user_id}">{escape_html(ten_day_du)}</a>'
        else:
            return f'<a href="tg://user?id={user_id}">ID: {user_id}</a>'
    except Exception as e:
        logger.error(f"Lỗi định dạng liên kết người dùng: {e}")
        return "Người dùng không rõ"

def lay_tieu_de_quyen(user_id):
    """Lấy tiêu đề quyền"""
    cap_do = lay_cap_do_quyen_nguoi_dung(user_id)
    tieu_de = {
        'admin': "╭━━࿗𓆰☯︎ 🎩 𝓐𝓭𝓶𝓲𝓷  ☯︎𓆪࿘━━╮",
        'vip': "╭━━❂༺𓆰🧞‍♂️🅥🅘🅟🧜🏻‍♀️𓆪༻❂━━╮",
        'member': "╭━━━━༉Members༉━━━━╮"
    }
    return tieu_de.get(cap_do, tieu_de['member'])

def get_carrier(phone):
    """Xác định nhà mạng từ số điện thoại"""
    if not phone:
        return "Không xác định"
    phone = str(phone).strip()
    if phone.startswith("+84"):
        phone = "0" + phone[3:]
    elif phone.startswith("84"):
        phone = "0" + phone[2:]
    if len(phone) < 3:
        return "Không xác định"
    prefix = phone[:3]
    viettel = {"086", "096", "097", "098", "032", "033", "034", "035", "036", "037", "038", "039"}
    mobifone = {"089", "090", "093", "070", "079", "077", "076", "078"}
    vinaphone = {"088", "091", "094", "083", "084", "085", "081", "082"}
    vietnamobile = {"092", "056", "058"}
    gmobile = {"099", "059"}
    if prefix in viettel:
        return "𝑉𝑖𝑒𝑡𝑡𝑒𝑙"
    elif prefix in mobifone:
        return "𝑀𝑜𝑏𝑖𝑓𝑜𝑛𝑒"
    elif prefix in vinaphone:
        return "𝑉𝑖𝑛𝑎𝑝ℎ𝑜𝑛𝑒"
    elif prefix in vietnamobile:
        return "𝑉𝑖𝑒𝑡𝑛𝑎𝑚𝑜𝑏𝑖𝑙𝑒"
    elif prefix in gmobile:
        return "𝐺𝑚𝑜𝑏𝑖𝑙𝑒"
    return "𝐾ℎ𝑜̂𝑛𝑔 𝑥𝑎́𝑐 𝑑𝑖̣𝑛ℎ"

def doc_file_js(ten_file):
    """Đọc danh sách từ file JavaScript"""
    try:
        if not os.path.exists(ten_file):
            return []

        with open(ten_file, 'r', encoding='utf-8') as file:
            noi_dung = file.read()

        # Tìm array trong file JS
        import re
        pattern = r'\[([^\]]+)\]'
        match = re.search(pattern, noi_dung, re.DOTALL)

        if match:
            array_content = match.group(1)
            # Tách các URL từ array
            urls = []
            for line in array_content.split('\n'):
                line = line.strip()
                if line.startswith('"') and line.endswith('",'):
                    url = line[1:-2]  # Bỏ dấu " và ,
                    urls.append(url)
                elif line.startswith('"') and line.endswith('"'):
                    url = line[1:-1]  # Bỏ dấu "
                    urls.append(url)
            return urls
        return []
    except Exception as e:
        logger.error(f"Lỗi đọc file JS {ten_file}: {e}")
        return []

def tao_keyboard_lien_ket_nhom():
    """Tạo inline keyboard với liên kết đến nhóm khác"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="🥷🏿   ㋰ 𓊈 𝐴𝑑𝑚𝑖𝑛 𝟸𝟺/𝟽 𓊉 ㋰   🛰️",
                url="https://t.me/@adimquanghau"
            )
        ]
    ])
    return keyboard

def create_router():
    """Tạo router mới với tất cả handlers"""
    router = Router()

    # Đăng ký tất cả handlers
    router.message.register(xu_ly_start, Command("start"))
    router.message.register(xu_ly_ping, Command("ping"))
    router.message.register(xu_ly_sms, Command("sms"))
    router.message.register(xu_ly_spam, Command("spam"))
    router.message.register(xu_ly_free, Command("free"))
    router.message.register(xu_ly_vip, Command("vip"))
    router.message.register(xu_ly_call, Command("call"))
    router.message.register(xu_ly_ddos, Command("ddos"))
    router.message.register(xu_ly_full, Command("full"))
    router.message.register(xu_ly_tiktok, Command("tiktok"))
    router.message.register(xu_ly_ngl, Command("ngl"))
    router.message.register(xu_ly_kill_tien_trinh, Command("kill"))
    router.message.register(xu_ly_checkid, Command("checkid"))
    router.message.register(xu_ly_kill_tat_ca_tien_trinh, Command("killall"))
    router.message.register(xu_ly_them_vip, Command("themvip"))
    router.message.register(xu_ly_xoa_vip, Command("xoavip"))
    router.message.register(xu_ly_them_admin, Command("themadmin"))
    router.message.register(xu_ly_xoa_admin, Command("xoaadmin"))
    router.message.register(xu_ly_xem_danh_sach_vip, Command("listvip"))
    router.message.register(xu_ly_don_dep_vps, Command("vps"))
    router.message.register(xu_ly_proxy, Command("prx"))
    router.message.register(xu_ly_random_anh, Command("img"))
    router.message.register(xu_ly_random_video, Command("vid"))
    router.message.register(xu_ly_tin_nhan_khong_phai_lenh)

    return router

async def gui_phan_hoi(message: Message, noi_dung: str, xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8, luu_vinh_vien=False, co_keyboard=False):
    try:
        chat_id = message.chat.id
        text = f"<blockquote>{noi_dung.strip()}</blockquote>"
        keyboard = tao_keyboard_lien_ket_nhom() if co_keyboard else None
        tasks = []
        send_task = bot.send_message(
            chat_id=chat_id,
            text=text,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
            reply_markup=keyboard
        )
        tasks.append(send_task)

        # Task xóa tin nhắn người dùng (nếu cần)
        if xoa_tin_nguoi_dung:
            delete_task = bot.delete_message(chat_id=chat_id, message_id=message.message_id)
            tasks.append(delete_task)

        # Chạy song song các tasks
        results = await asyncio.gather(*tasks, return_exceptions=True)
        sent_message = results[0] if not isinstance(results[0], Exception) else None

        if (sent_message and not isinstance(sent_message, Exception) and 
            tu_dong_xoa_sau_giay > 0 and not luu_vinh_vien):
            asyncio.create_task(tu_dong_xoa_tin_nhan(sent_message.chat.id, sent_message.message_id, tu_dong_xoa_sau_giay))

        return sent_message
    except Exception as e:
        logger.error(f"Lỗi khi gửi phản hồi: {e}")
        return None

async def tu_dong_xoa_tin_nhan(chat_id, message_id, tre=10):
    try:
        await asyncio.sleep(tre)
        await bot.delete_message(chat_id=chat_id, message_id=message_id)
    except Exception as e:
        logger.error(f"Lỗi khi tự động xóa tin nhắn ({chat_id}, {message_id}): {e}")

def them_vip(user_id, ten):
    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO admin (user_id, name, role) VALUES (?, ?, ?)",
            (str(user_id), ten, 'vip')
        )
        conn.commit()
        conn.close()

        # Xóa cache quyền ngay lập tức để cập nhật nhanh
        quan_ly_quyen_cache.cache.pop(str(user_id), None)
    except Exception as e:
        logger.error(f"Lỗi khi thêm VIP {user_id}: {e}")

def them_admin(user_id, ten):
    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO admin (user_id, name, role) VALUES (?, ?, ?)",
            (str(user_id), ten, 'admin')
        )
        conn.commit()
        conn.close()

        # Xóa cache quyền ngay lập tức để cập nhật nhanh
        quan_ly_quyen_cache.cache.pop(str(user_id), None)
    except Exception as e:
        logger.error(f"Lỗi khi thêm Admin {user_id}: {e}")

# ============ DECORATOR ============
def cooldown_nguoi_dung(giay_mac_dinh=60):
    """Decorator cooldown thống nhất - Tối ưu hóa"""
    def decorator(func):
        @wraps(func)
        async def wrapper(message: Message, *args, **kwargs):
            if not message.from_user:
                return False
            user_id = message.from_user.id
            ten_ham = func.__name__

            # Lấy quyền 1 lần và cache để tránh gọi lại
            cap_do = lay_cap_do_quyen_nguoi_dung(user_id)

            # Kiểm tra quyền required trước cooldown (nhanh hơn)
            quyen_yeu_cau = getattr(func, '_quyen_yeu_cau', None)
            if quyen_yeu_cau:
                if quyen_yeu_cau == 'admin' and cap_do != 'admin':
                    await gui_phan_hoi(message, "Không đủ quyền!", xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=3)
                    return False
                elif quyen_yeu_cau == 'vip_vinh_vien' and cap_do not in ('admin', 'vip'):
                    await gui_phan_hoi(message, "Không đủ quyền!", xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=3)
                    return False

            # Kiểm tra cooldown - admin bỏ qua một số cooldown
            if cap_do != 'admin':  # Admin skip cooldown check cho tốc độ
                dang_cooldown, thoi_gian_con_lai, _ = quan_ly_cooldown.kiem_tra_cooldown(user_id, ten_ham)
                if dang_cooldown:
                    thoi_gian_formatted = dinh_dang_thoi_gian_cooldown(thoi_gian_con_lai)
                    await gui_phan_hoi(
                        message,
                        f"🏓 𝐵𝑎̣𝑛 𝑐𝑎̂̀𝑛 𝑐ℎ𝑜̛̀ {thoi_gian_formatted} 𝑛𝑢̛̃𝑎 𝑑𝑒̂̉ 𝑠𝑢̛̉ 𝑑𝑢̣𝑛𝑔 𝑙𝑒̣̂𝑛ℎ 𝑛𝑎̀𝑦 !",
                        xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=5
                    )
                    return False

            # Thực thi lệnh
            ket_qua = await func(message, *args, **kwargs)

            # Chỉ đặt cooldown khi lệnh thành công và không phải admin
            if ket_qua is True and cap_do != 'admin':
                quan_ly_cooldown.dat_cooldown(user_id, ten_ham)

            return ket_qua
        return wrapper
    return decorator

def chi_nhom(func):
    """Decorator chỉ cho phép sử dụng trong nhóm"""
    @wraps(func)
    async def wrapper(message: Message, *args, **kwargs):
        if not message.from_user:
            return False
        user = message.from_user
        chat = message.chat
        if la_admin(user.id):
            return await func(message, *args, **kwargs)
        if not chat or chat.id != ID_NHOM_CHO_PHEP:
            return False
        return await func(message, *args, **kwargs)
    return wrapper

def chi_admin(func):
    func._quyen_yeu_cau = 'admin'
    return func

def chi_vip_vinh_vien(func):
    func._quyen_yeu_cau = 'vip_vinh_vien'
    return func

# ============ CÁC HANDLER LỆNH ============
def trich_xuat_tham_so(message: Message):
    if not message.text:
        return []
    return message.text.split()[1:]

@chi_nhom
async def xu_ly_start(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = f"""𝑀𝑟.𝑈𝑠𝑒𝑟   :    {lien_ket_nguoi_dung}

🚀 𝐿𝐸̣̂𝑁𝐻 𝐶𝑂̛ 𝐵𝐴̉𝑁:
 • /ping    -    𝑋𝑒𝑚 𝑇𝑟𝑎̣𝑛𝑔 𝑇ℎ𝑎́𝑖 𝐵𝑂𝑇
 • /checkid    -    𝑋𝑒𝑚 𝑇ℎ𝑜̂𝑛𝑔 𝑇𝑖𝑛 𝐼𝐷
 • /free    -    𝑆𝑝𝑎𝑚 𝑆𝑀𝑆 𝑍𝑎𝑙𝑜  

🔥 𝐿𝐸̣̂𝑁𝐻 𝑇𝐴̂́𝑁 𝐶𝑂̂𝑁𝐺:
 • /sms    -    𝑆𝑀𝑆 𝟻𝟶 𝑆𝑜̂́
 • /spam    -    𝑆𝑝𝑎𝑚 𝑙𝑖𝑒̂𝑛 𝑇𝑢̣𝑐
 • /ngl    -    𝑆𝑝𝑎𝑚 𝑁𝐺𝐿

💫 𝑉𝐼𝑃 𝑉𝐼̃𝑁𝐻 𝑉𝐼𝐸̂̃𝑁:
 • /call    -    𝐺𝑜̣𝑖 𝟷 𝑆𝑜̂́
 • /ddos    -    𝐷𝑎́𝑛ℎ 𝑆𝑎̣̂𝑝 𝑊𝑒𝑏
 • /vip    -    𝑆𝑀𝑆 𝐶𝑎𝑙𝑙 𝟷𝟶 𝑠𝑜̂́/𝑙𝑎̂̀𝑛
 • /full    -    𝐶ℎ𝑎̣𝑦 𝐹𝑢𝑙𝑙 ②④ⓗ
 • /tiktok    -    𝑇𝑎̆𝑛𝑔 𝑉𝑖𝑒𝑤 𝑇𝑖𝑘𝑇𝑜𝑘
 • /kill    -    𝐷𝑢̛̀𝑛𝑔 𝐿𝑒̣̂𝑛ℎ

🎬 𝐺𝐼𝐴̉𝐼 𝑇𝑅𝐼́:
 • /img    -    𝑅𝑎𝑛𝑑𝑜𝑚 𝐴̉𝑛ℎ
 • /vid    -    𝑅𝑎𝑛𝑑𝑜𝑚 𝑉𝑖𝑑𝑒𝑜
"""

    await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)
    return True

@chi_nhom
async def xu_ly_ping(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}

🤖 𝑇𝑟𝑎̣𝑛𝑔 𝑡ℎ𝑎́𝑖 𝐵𝑜𝑡 : ℎ𝑜𝑎̣𝑡 𝑑𝑜̣̂𝑛𝑔 🛰️

🚀 𝑆𝐴̆̃𝑁 𝑆𝐴̀𝑁𝐺 𝑁𝐻𝐴̣̂𝑁 𝐿𝐸̣̂𝑁𝐻 ! 🎯"""

    await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)
    return True

@cooldown_nguoi_dung()
@chi_nhom
async def xu_ly_sms(message: Message):
    # Kiểm tra lệnh có bị khóa không
    if await kiem_tra_lenh_bi_khoa(message, "sms"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if not cac_tham_so:
        gioi_han_so = lay_gioi_han_so_dien_thoai(user_id)
        await gui_phan_hoi(
            message,
            f"👼🏻 /𝑠𝑚𝑠 𝟶𝟿𝟾𝟿𝟿𝟿𝟶𝟶𝟶 𝟶𝟿𝟾𝟿𝟿𝟿𝟶𝟶𝟷..𝑇𝑜̂́𝑖 𝑑𝑎 {gioi_han_so} 𝑆𝑜̂́ 𝑡ℎ𝑒𝑜 𝑞𝑢𝑦𝑒̂̀𝑛 ℎ𝑖𝑒̣̂𝑛 𝑡𝑎̣𝑖 𝑐𝑢̉𝑎 𝑏𝑎̣𝑛 !",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Xử lý danh sách số trực tiếp
    gioi_han_so = lay_gioi_han_so_dien_thoai(user_id)
    if len(cac_tham_so) > gioi_han_so:
        await gui_phan_hoi(
            message,
            f"👼🏻 𝐵𝑎̣𝑛 𝑐ℎ𝑖̉ 𝑑𝑢̛𝑜̛̣𝑐 𝑝ℎ𝑒́𝑝 𝑛ℎ𝑎̣̂𝑝 𝑡𝑜̂́𝑖 𝑑𝑎 {gioi_han_so} 𝑆𝑜̂́!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    cac_so_hop_le = []
    for so in cac_tham_so:
        so = so.strip()
        if la_so_dien_thoai_hop_le(so) and not kiem_tra_so_full(user_id, so) and so not in cac_so_hop_le:
            cac_so_hop_le.append(so)

    if not cac_so_hop_le:
        await gui_phan_hoi(
            message,
            "👼🏻 Các số điện thoại đang chạy trong lệnh full 24h hoặc không hợp lệ!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Chọn script SMS với cache
    available_scripts = get_available_scripts(SCRIPT_VIP_DIRECT, 'sms')
    if not available_scripts:
        await gui_phan_hoi(
            message,
            f"👼🏻 Script SMS không khả dụng!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    script_duoc_chon = random.choice(available_scripts)

    danh_sach_so_chuoi = " ".join(cac_so_hop_le)
    command = f"proxychains4 python3 {script_duoc_chon} {danh_sach_so_chuoi}"

    thanh_cong, pid, _ = chay_tien_trinh_nen_sync(command, timeout=TIMEOUT_TRUNG_BINH, user_id=user_id)

    if not thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Không thể khởi tạo tiến trình!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟     :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷        :      {user_id}
╭━━━━━〔❨✧✧❩〕
 • 𝑁ℎ𝑎̣̂𝑝 𝑇𝑎𝑦          :      {len(cac_so_hop_le)} 𝑆𝑜̂́ 𝐻𝑜̛̣𝑝 𝑙𝑒̣̂
 • 𝑇𝑎̂́𝑛 𝐶𝑜̂𝑛𝑔           :       𝟼𝟶 𝑝ℎ𝑢́𝑡
 • 𝑉𝑖̣ 𝑡𝑟𝑖́                  :      𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛           :       {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦                :       {chuoi_ngay}
╰━━━━━〔❨✧𝐒𝐌𝐒✧❩〕"""

    # Gửi ảnh với keyboard
    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        # Xóa tin nhắn người dùng
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)
        
    return True

@cooldown_nguoi_dung()
@chi_nhom
async def xu_ly_spam(message: Message):
    # Kiểm tra lệnh có bị khóa không
    if await kiem_tra_lenh_bi_khoa(message, "spam"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 𝐶𝑢́ 𝑝ℎ𝑎́𝑝: /spam 𝟶𝟿𝟶𝟿𝟽𝟽𝟾𝟿𝟿𝟾",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    so_dien_thoai = cac_tham_so[0].strip()

    hop_le, thong_diep = xac_thuc_so_voi_nha_mang(so_dien_thoai)
    if not hop_le:
        await gui_phan_hoi(
            message,
            f"👼🏻 {thong_diep}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    if kiem_tra_so_full(user_id, so_dien_thoai):
        await gui_phan_hoi(
            message,
            f"👼🏻 Số {so_dien_thoai} 𝑑𝑎𝑛𝑔 𝑐ℎ𝑎̣𝑦 𝑓𝑢𝑙𝑙 𝟸𝟺ℎ!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    available_scripts = get_available_scripts(SCRIPT_SPAM_DIRECT, 'spam')
    if not available_scripts:
        await gui_phan_hoi(
            message,
            "👼🏻 Script Spam không khả dụng!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    script = random.choice(available_scripts)

    command = f"timeout 180s python3 {script} {so_dien_thoai} 5"
    thanh_cong, pid, _ = chay_tien_trinh_nen_sync(command, timeout=TIMEOUT_NGAN, user_id=user_id)

    if not thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Lỗi khi khởi động tiến trình!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    nha_mang = get_carrier(so_dien_thoai)
    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
╭━━━━〔❨✧✧❩〕
 • 𝑃ℎ𝑜𝑛𝑒 𝑉𝑁        :      {so_dien_thoai}
 • 𝑇𝑎̂́𝑛 𝐶𝑜̂𝑛𝑔        :      𝟷 𝐺𝑖𝑜̛̀ 𝑙𝑖𝑒̂𝑛 𝑡𝑢̣𝑐
 • 𝑁ℎ𝑎̀ 𝑚𝑎̣𝑛𝑔       :      {nha_mang}
 • 𝑉𝑖̣ 𝑡𝑟𝑖́                :      𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛         :      {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦              :      {chuoi_ngay}
╰━━━━〔❨✧𝐒𝐏𝐀𝐌✧❩〕"""

    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        # Xóa tin nhắn người dùng
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

@cooldown_nguoi_dung()
@chi_nhom
async def xu_ly_free(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 𝐶𝑢́ 𝑝ℎ𝑎́𝑝: /free 𝟶𝟿𝟶𝟿𝟽𝟽𝟾𝟿𝟿𝟾",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    so_dien_thoai = cac_tham_so[0].strip()

    hop_le, thong_diep = xac_thuc_so_voi_nha_mang(so_dien_thoai)
    if not hop_le:
        await gui_phan_hoi(
            message,
            f"👼🏻 {thong_diep}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    if kiem_tra_so_full(user_id, so_dien_thoai):
        await gui_phan_hoi(
            message,
            f"👼🏻 Số {so_dien_thoai} 𝑑𝑎𝑛𝑔 𝑐ℎ𝑎̣𝑦 𝑓𝑢𝑙𝑙 𝟸𝟺ℎ!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    script = random.choice(SCRIPT_FREE)

    command = f"timeout 180s python3 {script} {so_dien_thoai} 1"
    thanh_cong, pid, _ = chay_tien_trinh_nen_sync(command, timeout=TIMEOUT_NGAN, user_id=user_id)

    if not thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Lỗi khi khởi động tiến trình!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = (
        f"👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟   :     {lien_ket_nguoi_dung}\n"
        f"🎫 𝑀ã 𝐼𝐷      :     {user_id}\n"
        f"🚀 𝐿𝑒̣̂𝑛ℎ 𝑑𝑎̃ 𝑐ℎ𝑎̣𝑦 𝑡ℎ𝑎̀𝑛ℎ 𝑐𝑜̂𝑛𝑔 !🎯\n"
        f"𝐴𝐸 𝑡𝑒𝑠𝑡 𝑡ℎ𝑢̛̉ 𝑠𝑜̂́ 𝑟𝑜̂̀𝑖 𝑐ℎ𝑜 𝑚𝑖̀𝑛ℎ 𝑥𝑖𝑛 𝑦́ 𝑘𝑖𝑒̂́𝑛 !"
    )

    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass
    except Exception as e:
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

# VIP COMMANDS
@cooldown_nguoi_dung()
@chi_nhom
@chi_vip_vinh_vien
async def xu_ly_vip(message: Message):
    if await kiem_tra_lenh_bi_khoa(message, "vip"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if not cac_tham_so:
        await gui_phan_hoi(
            message,
            "👼🏻 /vip 𝟶𝟿𝟾𝟿𝟸𝟿𝟿𝟿𝟶𝟿...𝑇𝑜̂́𝑖 𝑑𝑎 𝟷𝟶 𝑠𝑜̂́",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Xử lý danh sách số trực tiếp (tối đa 10 số)
    if len(cac_tham_so) > 10:
        await gui_phan_hoi(
            message,
            "👼🏻 𝐿𝑒̣̂𝑛ℎ /vip 𝑐ℎ𝑖̉ 𝑐ℎ𝑜 𝑝ℎ𝑒́𝑝 𝑡𝑜̂́𝑖 𝑑𝑎 𝟷𝟶 𝑠𝑜̂́!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    cac_so_hop_le = []
    for so in cac_tham_so[:10]:
        so = so.strip()
        if la_so_dien_thoai_hop_le(so) and not kiem_tra_so_full(user_id, so) and so not in cac_so_hop_le:
            cac_so_hop_le.append(so)

    if not cac_so_hop_le:
        await gui_phan_hoi(
            message,
            "👼🏻 Các số điện thoại đang chạy trong lệnh full 24h hoặc không hợp lệ!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    available_scripts = get_available_scripts(SCRIPT_SMS_DIRECT, 'vip')
    if not available_scripts:
        await gui_phan_hoi(
            message,
            "👼🏻 Không có script VIP nào khả dụng!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Chạy nhiều script song song với batch processing
    cac_pid_thanh_cong = []

    # Chia thành batch nhỏ để tránh quá tải
    batch_size = 3
    for i in range(0, len(cac_so_hop_le), batch_size):
        batch = cac_so_hop_le[i:i + batch_size]

        # Chạy đồng thời trong batch
        for j, so in enumerate(batch):
            script_index = (i + j) % len(available_scripts)
            script_duoc_chon = available_scripts[script_index]
            command = f"proxychains4 python3 {script_duoc_chon} {so} 5"
            thanh_cong, pid, _ = chay_tien_trinh_nen_sync(command, timeout=TIMEOUT_NGAN, user_id=user_id)
            if thanh_cong and pid:
                cac_pid_thanh_cong.append(pid)

        # Delay nhỏ giữa các batch để tránh spam
        if i + batch_size < len(cac_so_hop_le):
            await asyncio.sleep(0.1)

    if not cac_pid_thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Không thể khởi tạo tiến trình nào!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
╭━━━━━〔❨✧✧❩〕
 • 𝑁ℎ𝑎̣̂𝑝 𝑇𝑎𝑦        :      {len(cac_so_hop_le)} 𝑠𝑜̂́ 𝐻𝑜̛̣𝑝 𝑙𝑒̣̂
 • 𝑆𝑜̂́ 𝑣𝑜̀𝑛𝑔            :      𝟹𝟶 𝑉𝑜̀𝑛𝑔
 • 𝑉𝑖̣ 𝑡𝑟𝑖́                :       𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛         :       {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦              :       {chuoi_ngay}
╰━━━━━〔❨✧𝐕𝐈𝐏✧❩〕"""

    # Gửi ảnh với keyboard
    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

@cooldown_nguoi_dung()
@chi_nhom
@chi_vip_vinh_vien
async def xu_ly_call(message: Message):
    # Kiểm tra lệnh có bị khóa không
    if await kiem_tra_lenh_bi_khoa(message, "call"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 𝐶𝑢́ 𝑝ℎ𝑎́𝑝: /call 𝟶𝟿𝟾𝟿𝟸𝟸𝟼𝟿𝟿𝟾",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    so_dien_thoai = cac_tham_so[0].strip()

    hop_le, thong_diep = xac_thuc_so_voi_nha_mang(so_dien_thoai)
    if not hop_le:
        await gui_phan_hoi(
            message,
            f"👼🏻 {thong_diep}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    if kiem_tra_so_full(user_id, so_dien_thoai):
        await gui_phan_hoi(
            message,
            f"👼🏻 𝑆𝑜̂́ {so_dien_thoai} 𝑑𝑎𝑛𝑔 𝑐ℎ𝑎̣𝑦 𝑓𝑢𝑙𝑙 𝟸𝟺ℎ!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    available_scripts = get_available_scripts(SCRIPT_CALL_DIRECT, 'call')
    if not available_scripts:
        await gui_phan_hoi(
            message,
            "👼🏻 Không có script Call nào khả dụng!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    script = random.choice(available_scripts)
    command = f"python3 {script} {so_dien_thoai} 2"

    thanh_cong, pid, _ = chay_tien_trinh_nen_sync(command, timeout=TIMEOUT_NGAN, user_id=user_id)

    if not thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Lỗi khi khởi động tiến trình!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    nha_mang = get_carrier(so_dien_thoai)
    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
╭━━━━━〔❨✧✧❩〕
 • 𝑃ℎ𝑜𝑛𝑒 𝑉𝑁       :     {so_dien_thoai}
 • 𝐿𝑎̣̆𝑝 𝑙𝑎̣𝑖             :     𝟿𝟿 𝐿𝑎̂̀𝑛
 • 𝑁ℎ𝑎̀ 𝑚𝑎̣𝑛𝑔       :     {nha_mang}
 • 𝑉𝑖̣ 𝑡𝑟𝑖́                :      𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛        :      {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦              :      {chuoi_ngay}
╰━━━━〔❨✧𝐂𝐀𝐋𝐋✧❩〕"""

    # Gửi ảnh với keyboard
    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        # Xóa tin nhắn người dùng
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

@cooldown_nguoi_dung()
@chi_nhom
@chi_vip_vinh_vien
async def xu_ly_ddos(message: Message):
    # Kiểm tra lệnh có bị khóa không
    if await kiem_tra_lenh_bi_khoa(message, "ddos"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 Cú pháp: /ddos [link web]",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    url_muc_tieu = cac_tham_so[0].strip()
    if not any(url_muc_tieu.startswith(proto) for proto in ['http://', 'https://']):
        url_muc_tieu = 'http://' + url_muc_tieu

    script_ddos = "tcp.py"
    thanh_cong, pid, file_log = chay_tien_trinh_nen_sync(
        f"python3 {script_ddos} {url_muc_tieu} 1000",
        timeout=TIMEOUT_TRUNG_BINH
    )

    if not thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Lỗi khi khởi động lệnh ddos!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)
    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
╭━━━━━〔❨✧✧❩〕
 • Target       :     {escape_html(url_muc_tieu[:25])}...
 • 𝑆𝑜̂́ vòng          :     Liên tục
 • Power          :     High Performance
 • 𝑉𝑖̣ 𝑡𝑟𝑖́                :      𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛        :      {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦              :      {chuoi_ngay}
╰━━━━〔❨✧𝗗𝗗𝗢𝗦✧❩〕"""

    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        # Xóa tin nhắn người dùng
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

@cooldown_nguoi_dung()
@chi_nhom
@chi_vip_vinh_vien
async def xu_ly_full(message: Message):
    # Kiểm tra lệnh có bị khóa không
    if await kiem_tra_lenh_bi_khoa(message, "full"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if not cac_tham_so:
        await gui_phan_hoi(
            message,
            "👼🏻 𝐶𝑢́ 𝑝ℎ𝑎́𝑝: /full 𝟶𝟿𝟶𝟿𝟽𝟽𝟾𝟿𝟿𝟾 𝟶𝟿𝟶𝟿𝟽𝟽𝟾𝟿𝟿𝟽...\n𝐶ℎ𝑎̣𝑦 𝑙𝑖𝑒̂𝑛 𝑡𝑢̣𝑐 𝟸𝟺ℎ - 𝑉𝐼𝑃 𝑡𝑜̂́𝑖 𝑑𝑎 𝟹 𝑠𝑜̂́ 𝑚𝑜̂̃𝑖 𝑙𝑎̂̀𝑛 !",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Giới hạn số lượng số điện thoại cho VIP (tối đa 3 số)
    if len(cac_tham_so) > 3:
        await gui_phan_hoi(
            message,
            "👼🏻 𝑉𝐼𝑃 𝑐ℎ𝑖̉ 𝑑𝑢̛𝑜̛̣𝑐 𝑝ℎ𝑒́𝑝 𝑛ℎ𝑎̣̂𝑝 𝑡𝑜̂́𝑖 𝑑𝑎 𝟹 𝑆𝑜̂́ 𝑐ℎ𝑜 𝑙𝑒̣̂𝑛ℎ 𝑓𝑢𝑙𝑙!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    cac_so_hop_le = []
    for so in cac_tham_so:
        so = so.strip()
        if la_so_dien_thoai_hop_le(so) and not kiem_tra_so_full(user_id, so) and so not in cac_so_hop_le:
            cac_so_hop_le.append(so)

    if not cac_so_hop_le:
        await gui_phan_hoi(
            message,
            "👼🏻 𝐾ℎ𝑜̂𝑛𝑔 𝑐𝑜́ 𝑆𝑜̂́ 𝑑𝑖𝑒̣̂𝑛 𝑡ℎ𝑜𝑎̣𝑖 ℎ𝑜̛̣𝑝 𝑙𝑒̣̂ 𝑛𝑎̀𝑜!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Kiểm tra user đã có số full chưa
    with FULL_LOCK:
        user_full_count = sum(1 for key in FULL_STATUS.keys() if key.startswith(f"{user_id}:"))
        if user_full_count + len(cac_so_hop_le) > 3:
            await gui_phan_hoi(
                message,
                f"👼🏻 𝐵𝑎̣𝑛 𝑑𝑎̃ 𝑐𝑜́ {user_full_count} 𝑠𝑜̂́ 𝑑𝑎𝑛𝑔 𝐹𝑢𝑙𝑙. 𝑉𝐼𝑃 𝑐ℎ𝑖̉ 𝑑𝑢̛𝑜̛̣𝑐 𝑡𝑜̂́𝑖 𝑑𝑎 𝟹 𝑠𝑜̂́!",
                xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
            )
            return False

    # Chạy nhiều số song song
    cac_pid_thanh_cong = []
    cac_so_thanh_cong = []

    for so in cac_so_hop_le:
        # Đặt trạng thái full trước khi chạy
        dat_trang_thai_full(user_id, so)

        command = f"timeout 1200s python3 pro24h.py {so}"
        thanh_cong, pid, _ = chay_tien_trinh_nen_sync(command, timeout=TIMEOUT_MO_RONG, user_id=user_id)

        if thanh_cong and pid:
            cac_pid_thanh_cong.append(pid)
            cac_so_thanh_cong.append(so)
        else:
            xoa_trang_thai_full(user_id, so)

    if not cac_pid_thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Không thể khởi tạo tiến trình full nào!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    danh_sach_so = ", ".join(cac_so_thanh_cong)

    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
╭━━━━━〔❨✧✧❩〕
 • 𝑃ℎ𝑜𝑛𝑒 𝐵𝑙𝑜𝑐𝑘     :      {len(cac_so_thanh_cong)} 𝑠𝑜̂́ 𝐻𝑜̛̣𝑝 𝑙𝑒̣̂
 • 𝐷𝑎𝑛ℎ 𝑠𝑎́𝑐ℎ        :      {danh_sach_so}
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛          :      𝟸𝟺 𝐺𝑖𝑜̛̀ 𝑙𝑖𝑒̂𝑛 𝑡𝑢̣𝑐
 • 𝑇𝑟𝑎̣𝑛𝑔 𝑡ℎ𝑎́𝑖        :       𝐷𝑎𝑛𝑔 𝑔𝑢̛̉𝑖 𝑂𝑇𝑃
 • 𝑉𝑖̣ 𝑡𝑟𝑖́                  :      𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛           :      {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦                :      {chuoi_ngay}
 • 📵 𝑈𝑛𝑙𝑜𝑐𝑘         :      /kill 𝐷𝑢̛̀𝑛𝑔 𝑠𝑜̂́
╰━━━〔❨✧𝐅𝐮𝐥𝐥 𝟐𝟒/𝟕✧❩〕"""

    # Gửi ảnh với keyboard
    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        # Xóa tin nhắn người dùng
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

@cooldown_nguoi_dung()
@chi_nhom
@chi_vip_vinh_vien
async def xu_ly_tiktok(message: Message):
    """Xử lý lệnh TikTok"""
    # Kiểm tra lệnh có bị khóa không
    if await kiem_tra_lenh_bi_khoa(message, "tiktok"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 Cú pháp: /tiktok [link video tiktok]",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8,
            co_keyboard=True
        )
        return False

    link_tiktok = cac_tham_so[0].strip()

    if not ("tiktok.com" in link_tiktok or "vm.tiktok.com" in link_tiktok):
        await gui_phan_hoi(
            message,
            "👼🏻 Link TikTok không hợp lệ!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8,
            co_keyboard=True
        )
        return False

    script_tiktok = "tt.py"
    thanh_cong, pid, file_log = chay_tien_trinh_nen_sync(
        f"python3 {script_tiktok} {link_tiktok} 1000",
        timeout=TIMEOUT_MO_RONG
    )

    if not thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Lỗi khi khởi động lệnh tiktok!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8,
            co_keyboard=True
        )
        return False

    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)
    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
╭━━━━━〔❨✧✧❩〕
 • Link          :     {escape_html(link_tiktok[:30])}...
 • Target          :      1000+ views
 • 𝑉𝑖̣ 𝑡𝑟𝑖́        :     𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛.      :      {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦             :      {chuoi_ngay}
╰━━━━〔❨✧𝐓𝐢𝐤𝐓𝐨𝐤✧❩〕"""

    # Gửi ảnh với keyboard
    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        # Xóa tin nhắn người dùng
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

@cooldown_nguoi_dung()
@chi_nhom
@chi_vip_vinh_vien
async def xu_ly_ngl(message: Message):
    """Xử lý lệnh NGL"""
    # Kiểm tra lệnh có bị khóa không
    if await kiem_tra_lenh_bi_khoa(message, "ngl"):
        return False

    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 Cú pháp: /ngl [link ngl]",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8,
            co_keyboard=True
        )
        return False

    link_ngl = cac_tham_so[0].strip()

    if not ("ngl.link" in link_ngl):
        await gui_phan_hoi(
            message,
            "👼🏻 Link NGL không hợp lệ!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8,
            co_keyboard=True
        )
        return False

    script_ngl = "spamngl.py"
    thanh_cong, pid, file_log = chay_tien_trinh_nen_sync(
        f"python3 {script_ngl} {link_ngl} 1000",
        timeout=TIMEOUT_MO_RONG
    )

    if not thanh_cong:
        await gui_phan_hoi(
            message,
            "👼🏻 Lỗi khi khởi động lệnh NGL!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8,
            co_keyboard=True
        )
        return False

    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)
    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
╭━━━━━〔❨✧✧❩〕
 • Link         :     {escape_html(link_ngl[:30])}...
 • Target           :     1000+ messages
 • 𝑉𝑖̣ 𝑡𝑟𝑖́        :     𝑉/𝑁 𝑂𝑛𝑙𝑖𝑛𝑒
 • 𝑇ℎ𝑜̛̀𝑖 𝑔𝑖𝑎𝑛      :     {chuoi_gio}
 • 𝑇𝑜𝑑𝑎𝑦             :     {chuoi_ngay}
╰━━━━〔❨✧𝐍𝐆𝐋✧❩〕"""

    # Gửi ảnh với keyboard
    try:
        keyboard = tao_keyboard_lien_ket_nhom()
        await bot.send_photo(
            chat_id=message.chat.id,
            photo="https://files.catbox.moe/59n41m.jpeg",
            caption=f"<blockquote>{noi_dung}</blockquote>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard
        )

        # Xóa tin nhắn người dùng
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

    except Exception as e:
        # Fallback về text nếu không gửi được ảnh
        logger.error(f"Lỗi gửi ảnh: {e}")
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

    return True

@cooldown_nguoi_dung()
@chi_nhom
@chi_vip_vinh_vien
async def xu_ly_kill_tien_trinh(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id

    pattern = f"lenh.*{user_id}"
    thanh_cong = tat_tien_trinh_dong_bo(pattern)
    
    with FULL_LOCK:
        keys_to_remove = [key for key in FULL_STATUS.keys() if key.startswith(f"{user_id}:")]
        for key in keys_to_remove:
            FULL_STATUS.pop(key, None)

    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    if thanh_cong:
        noi_dung = f"User : {lien_ket_nguoi_dung}\nĐã dừng tất cả tiến trình của bạn!"
    else:
        noi_dung = f"User : {lien_ket_nguoi_dung}\nKhông tìm thấy tiến trình nào để dừng!"

    await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8)
    return True

@chi_nhom
async def xu_ly_checkid(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    ten_day_du = user.full_name or 'Unknown'

    cap_do = lay_cap_do_quyen_nguoi_dung(user_id)
    tieu_de_quyen = lay_tieu_de_quyen(user_id)
    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    noi_dung = f"""{tieu_de_quyen}
┃• 👼🏻 𝑀𝑟.𝑈𝑠𝑒𝑟    :      {lien_ket_nguoi_dung}
┃• 🎫 𝑀ã 𝐼𝐷       :      {user_id}
┃• ✨ 𝑄𝑢𝑦𝑒̂̀𝑛      :      {cap_do}"""

    await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)

# ADMIN COMMAND
@cooldown_nguoi_dung()
@chi_nhom
@chi_admin
async def xu_ly_kill_tat_ca_tien_trinh(message: Message):
    if not message.from_user:
        return False
    user = message.from_user

    thanh_cong = tat_tien_trinh_dong_bo("python.*lenh")

    with FULL_LOCK:
        FULL_STATUS.clear()

    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)

    if thanh_cong:
        noi_dung = f"𝐴𝑑𝑚𝑖𝑛 : {lien_ket_nguoi_dung}\n𝐷𝑎̃ 𝑑𝑢̛̀𝑛𝑔 𝑇𝐴̂́𝑇 𝐶𝐴̉ 𝑡𝑖𝑒̂́𝑛 𝑡𝑟𝑖̀𝑛ℎ 𝑡𝑟𝑜𝑛𝑔 ℎ𝑒̣̂ 𝑡ℎ𝑜̂́𝑛𝑔!"
    else:
        noi_dung = f"𝐴𝑑𝑚𝑖𝑛 : {lien_ket_nguoi_dung}\n𝐾ℎ𝑜̂𝑛𝑔 𝑡𝑖̀𝑚 𝑡ℎ𝑎̂́𝑦 𝑡𝑖𝑒̂́𝑛 𝑡𝑟𝑖̀𝑛ℎ 𝑛𝑎̀𝑜 𝑑𝑒̂̉ 𝑑𝑢̛̀𝑛𝑔!"

    await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=10)
    return True

@cooldown_nguoi_dung()
@chi_nhom
@chi_admin
async def xu_ly_them_vip(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) < 1:
        await gui_phan_hoi(
            message,
            "👼🏻 Cú pháp: /themvip USER_ID [TÊN]",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    id_muc_tieu = cac_tham_so[0].strip()
    ten_muc_tieu = " ".join(cac_tham_so[1:]) if len(cac_tham_so) > 1 else "VIP User"

    try:
        them_vip(id_muc_tieu, ten_muc_tieu)
        noi_dung = f"Đã thêm VIP: {id_muc_tieu} - {ten_muc_tieu}"
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True)
        return True
    except Exception as e:
        await gui_phan_hoi(
            message,
            f"Lỗi khi thêm VIP: {str(e)}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@cooldown_nguoi_dung()
@chi_nhom
@chi_admin
async def xu_ly_xoa_vip(message: Message):
    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 Cú pháp: /xoavip USER_ID",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    id_muc_tieu = cac_tham_so[0].strip()

    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM admin WHERE user_id = ? AND role = 'vip'", (id_muc_tieu,))
        so_hang_xoa = cursor.rowcount
        conn.commit()
        conn.close()

        # Xóa cache quyền ngay lập tức để cập nhật nhanh
        quan_ly_quyen_cache.cache.pop(str(id_muc_tieu), None)

        if so_hang_xoa > 0:
            noi_dung = f"Đã xóa VIP: {id_muc_tieu}"
        else:
            noi_dung = f"Không tìm thấy VIP: {id_muc_tieu}"

        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True)
        return True
    except Exception as e:
        await gui_phan_hoi(
            message,
            f"Lỗi khi xóa VIP: {str(e)}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@cooldown_nguoi_dung()
@chi_nhom
@chi_admin
async def xu_ly_them_admin(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) < 1:
        await gui_phan_hoi(
            message,
            "👼🏻 Cú pháp: /themadmin USER_ID [TÊN]",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    id_muc_tieu = cac_tham_so[0].strip()
    ten_muc_tieu = " ".join(cac_tham_so[1:]) if len(cac_tham_so) > 1 else "Admin User"

    if id_muc_tieu == str(user.id):
        await gui_phan_hoi(
            message,
            "Không thể tự thêm admin cho chính mình!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    try:
        them_admin(id_muc_tieu, ten_muc_tieu)
        noi_dung = f"Đã thêm Admin: {id_muc_tieu} - {ten_muc_tieu}"
        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True)
        return True
    except Exception as e:
        await gui_phan_hoi(
            message,
            f"Lỗi khi thêm Admin: {str(e)}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@cooldown_nguoi_dung()
@chi_nhom
@chi_admin
async def xu_ly_xoa_admin(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    cac_tham_so = trich_xuat_tham_so(message)

    if len(cac_tham_so) != 1:
        await gui_phan_hoi(
            message,
            "👼🏻 Cú pháp: /xoaadmin USER_ID",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    id_muc_tieu = cac_tham_so[0].strip()

    if id_muc_tieu == ID_ADMIN_MAC_DINH:
        await gui_phan_hoi(
            message,
            "Không thể xóa Super Admin!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    if id_muc_tieu == str(user.id):
        await gui_phan_hoi(
            message,
            "Không thể tự xóa admin của chính mình!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM admin WHERE user_id = ? AND role = 'admin'", (id_muc_tieu,))
        so_hang_xoa = cursor.rowcount
        conn.commit()
        conn.close()

        # Xóa cache quyền ngay lập tức để cập nhật nhanh
        quan_ly_quyen_cache.cache.pop(str(id_muc_tieu), None)

        if so_hang_xoa > 0:
            noi_dung = f"Đã xóa Admin: {id_muc_tieu}"
        else:
            noi_dung = f"Không tìm thấy Admin: {id_muc_tieu}"

        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True)
        return True
    except Exception as e:
        await gui_phan_hoi(
            message,
            f"Lỗi khi xóa Admin: {str(e)}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@chi_nhom
@chi_admin
async def xu_ly_xem_danh_sach_vip(message: Message):
    try:
        conn = tao_ket_noi_db()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, name, role FROM admin ORDER BY role, user_id")
        danh_sach = cursor.fetchall()
        conn.close()

        if not danh_sach:
            await gui_phan_hoi(
                message,
                "📋Chưa có VIP/Admin nào trong hệ thống!",
                xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=15
            )
            return False

        noi_dung = "📋 DANH SÁCH VIP & ADMIN:\n\n"

        admin_list = []
        vip_list = []

        for item in danh_sach:
            if item[2] == 'admin':
                admin_list.append(item)
            elif item[2] == 'vip':
                vip_list.append(item)

        if admin_list:
            noi_dung += "👑 ADMIN:\n"
            for i, admin in enumerate(admin_list, 1):
                noi_dung += f"  {i}. {admin[1]} ({admin[0]})\n"
            noi_dung += "\n"

        if vip_list:
            noi_dung += "VIP:\n"
            for i, vip in enumerate(vip_list, 1):
                noi_dung += f"  {i}. {vip[1]} ({vip[0]})\n"

        noi_dung += f"\nTổng: {len(admin_list)} Admin, {len(vip_list)} VIP"

        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True)
        return True

    except Exception as e:
        await gui_phan_hoi(
            message,
            f"Lỗi khi lấy danh sách: {str(e)}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@cooldown_nguoi_dung()
@chi_nhom
@chi_admin
async def xu_ly_don_dep_vps(message: Message):
    """Xử lý lệnh dọn dẹp VPS - chỉ thông báo 1 lần"""
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)
    tieu_de_quyen = lay_tieu_de_quyen(user_id)

    try:
        # Chạy script dọn dẹp VPS không đồng bộ
        chay_tien_trinh_nen_sync("python3 vps.py", timeout=180, user_id=user_id)

        noi_dung = f""" Admin      :     {lien_ket_nguoi_dung}\nDọn dẹp hệ thống thành công !"""

        await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)
        return True

    except FileNotFoundError:
        await gui_phan_hoi(
            message,
            "👼🏻 Không tìm thấy file vps.py!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False
    except Exception as e:
        logger.error(f"Lỗi khi khởi động VPS cleanup: {e}")
        await gui_phan_hoi(
            message,
            f"👼🏻 Lỗi khi khởi động VPS cleanup: {str(e)}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@cooldown_nguoi_dung()
@chi_nhom
@chi_admin
async def xu_ly_proxy(message: Message):
    """Xử lý lệnh proxy - chỉ thông báo 1 lần"""
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id

    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()
    tieu_de_quyen = lay_tieu_de_quyen(user_id)

    try:
        # Chạy script proxy không đồng bộ
        thanh_cong, pid, _ = chay_tien_trinh_nen_sync("python3 1.py", timeout=300, user_id=user_id)

        if thanh_cong:
            noi_dung = f"""Admin    :     {lien_ket_nguoi_dung}\nĐang lọc proxy, kết thúc sau 30p nữa !"""


            await gui_phan_hoi(message, noi_dung, xoa_tin_nguoi_dung=True, luu_vinh_vien=True, co_keyboard=True)
            return True
        else:
            await gui_phan_hoi(
                message,
                "👼🏻 Không thể khởi động proxy service!",
                xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
            )
            return False

    except FileNotFoundError:
        await gui_phan_hoi(
            message,
            "👼🏻 Không tìm thấy file 1.py!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False
    except Exception as e:
        logger.error(f"Lỗi khi khởi động proxy: {e}")
        await gui_phan_hoi(
            message,
            f"👼🏻 Lỗi khi khởi động proxy: {str(e)}",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@chi_nhom
async def xu_ly_random_anh(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id

    # Đọc danh sách ảnh từ file
    danh_sach_anh = doc_file_js("images.js")

    if not danh_sach_anh:
        await gui_phan_hoi(
            message,
            "👼🏻 Không tìm thấy danh sách ảnh!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Chọn ảnh random
    anh_random = random.choice(danh_sach_anh)

    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    try:
        await asyncio.wait_for(
            bot.send_photo(
                chat_id=message.chat.id,
                photo=anh_random,
                caption=f"<blockquote>🏓 𝑅𝑎𝑛𝑑𝑜𝑚 𝐴̉𝑛ℎ 𝑐ℎ𝑜 {lien_ket_nguoi_dung}\n"
                       f"⏱️ Thời gian: {chuoi_gio} - {chuoi_ngay}</blockquote>",
                parse_mode=ParseMode.HTML,
            ),
            timeout=30.0
        )

        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

        return True

    except asyncio.TimeoutError:
        await gui_phan_hoi(
            message,
            "👼🏻 Timeout khi tải ảnh! Thử lại sau.",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False
    except Exception as e:
        logger.error(f"Lỗi gửi ảnh: {e}")
        if "failed to get HTTP URL content" in str(e) and len(danh_sach_anh) > 1:
            anh_backup = random.choice([a for a in danh_sach_anh if a != anh_random])
            try:
                await bot.send_photo(
                    chat_id=message.chat.id,
                    photo=anh_backup,
                    caption=f"<blockquote>🏓 𝑅𝑎𝑛𝑑𝑜𝑚 𝐴̉𝑛ℎ 𝑐ℎ𝑜 {lien_ket_nguoi_dung}\n"
                           f"⏱️ Thời gian: {chuoi_gio} - {chuoi_ngay}</blockquote>",
                    parse_mode=ParseMode.HTML,
                )
                return True
            except Exception:
                pass

        await gui_phan_hoi(
            message,
            "👼🏻 Không thể tải ảnh! URL có thể bị lỗi.",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

@chi_nhom
async def xu_ly_random_video(message: Message):
    if not message.from_user:
        return False
    user = message.from_user
    user_id = user.id
    danh_sach_video = doc_file_js("videos.js")
    danh_sach_gif = doc_file_js("video2.js")

    tat_ca_video = danh_sach_video + danh_sach_gif

    if not tat_ca_video:
        await gui_phan_hoi(
            message,
            "👼🏻 Không tìm thấy danh sách video!",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False

    # Chọn video random
    video_random = random.choice(tat_ca_video)

    lien_ket_nguoi_dung = dinh_dang_lien_ket_nguoi_dung(user)
    chuoi_gio, chuoi_ngay = lay_thoi_gian_vn()

    try:
        if video_random.endswith('.gif') or 'giphy' in video_random:
            # Gửi GIF
            await asyncio.wait_for(
                bot.send_animation(
                    chat_id=message.chat.id,
                    animation=video_random,
                    caption=f"<blockquote>🎬 𝑅𝑎𝑛𝑑𝑜𝑚 𝐺𝐼𝐹 𝑐ℎ𝑜 {lien_ket_nguoi_dung}\n"
                           f"⏱️ Thời gian: {chuoi_gio} - {chuoi_ngay}</blockquote>",
                    parse_mode=ParseMode.HTML,
                ),
                timeout=45.0
            )
        else:
            await asyncio.wait_for(
                bot.send_video(
                    chat_id=message.chat.id,
                    video=video_random,
                    caption=f"<blockquote>🎬 𝑅𝑎𝑛𝑑𝑜𝑚 𝑉𝑖𝑑𝑒𝑜 𝑐ℎ𝑜 {lien_ket_nguoi_dung}\n"
                           f"⏱️ Thời gian: {chuoi_gio} - {chuoi_ngay}</blockquote>",
                    parse_mode=ParseMode.HTML,
                ),
                timeout=45.0
            )

        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass

        return True

    except asyncio.TimeoutError:
        await gui_phan_hoi(
            message,
            "👼🏻 Timeout khi tải video! File quá lớn.",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False
    except Exception as e:
        logger.error(f"Lỗi gửi video: {e}")
        if "failed to get HTTP URL content" in str(e) and len(tat_ca_video) > 1:
            video_backup = random.choice([v for v in tat_ca_video if v != video_random])
            try:
                if video_backup.endswith('.gif') or 'giphy' in video_backup:
                    await bot.send_animation(
                        chat_id=message.chat.id,
                        animation=video_backup,
                        caption=f"<blockquote>🎬 Random GIF cho {lien_ket_nguoi_dung}\n"
                               f"⏱️ Thời gian: {chuoi_gio} - {chuoi_ngay}</blockquote>",
                        parse_mode=ParseMode.HTML,
                    )
                else:
                    await bot.send_video(
                        chat_id=message.chat.id,
                        video=video_backup,
                        caption=f"<blockquote>🎬 Random Video cho {lien_ket_nguoi_dung}\n"
                               f"⏱️ Thời gian: {chuoi_gio} - {chuoi_ngay}</blockquote>",
                        parse_mode=ParseMode.HTML,
                    )
                return True
            except Exception:
                pass

        await gui_phan_hoi(
            message,
            "👼🏻 Không thể tải video! URL có thể bị lỗi.",
            xoa_tin_nguoi_dung=True, tu_dong_xoa_sau_giay=8
        )
        return False



async def xu_ly_tin_nhan_khong_phai_lenh(message: Message):
    try:
        if not message.from_user:
            return
        user_id = message.from_user.id
        is_bot = message.from_user.is_bot or False

        if message.from_user.is_bot:
            return

        if message.chat.id != ID_NHOM_CHO_PHEP:
            if la_admin(user_id):
                return

            try:
                await bot.send_message(
                    chat_id=message.chat.id,
                    text="<blockquote>🏓 𝐵𝑜𝑡 𝑐ℎ𝑖̉ ℎ𝑜𝑎̣𝑡 𝑑𝑜̣̂𝑛𝑔 𝑡𝑟𝑜𝑛𝑔 𝑛ℎ𝑜́𝑚:\n\n"

                         "🚀 @spamsmsbottienichquanghau 🎯\n\n"

                         "𝑇𝑖𝑛 𝑛ℎ𝑎̆́𝑛 𝑡𝑖𝑒̂́𝑝 𝑡ℎ𝑒𝑜 𝑠𝑒̃ 𝑏𝑖̣ 𝑥𝑜́𝑎 𝑡𝑢̛̣ 𝑑𝑜̣̂𝑛𝑔 !</blockquote>",
                    parse_mode=ParseMode.HTML
                )
            except Exception:
                pass

            try:
                await bot.delete_message(
                    chat_id=message.chat.id,
                    message_id=message.message_id
                )
            except Exception:
                pass
            return
        try:
            await bot.delete_message(
                chat_id=message.chat.id,
                message_id=message.message_id
            )
        except Exception:
            pass
        if message.text and message.text.startswith('/'):
            cac_lenh_hop_le = ['/start', '/vip', '/checkid', '/call', '/sms',
                             '/spam', '/ping', '/full', '/ddos',
                             '/kill', '/killall', '/themvip', '/xoavip',
                             '/themadmin', '/xoaadmin', '/listvip', '/vps', '/prx',
                             '/img', '/vid', '/tiktok', '/ngl']

            phan_lenh = message.text.split()[0]
            if '@' in phan_lenh:
                lenh = phan_lenh.split('@')[0]
            else:
                lenh = phan_lenh

            if lenh not in cac_lenh_hop_le:
                try:
                    phan_hoi = await bot.send_message(
                        chat_id=message.chat.id,
                        text="<blockquote>🏓 𝐶ℎ𝑖̉ 𝑠𝑢̛̉ 𝑑𝑢̣𝑛𝑔 𝑐𝑎́𝑐 𝑙𝑒̣̂𝑛ℎ 𝑑𝑢̛𝑜̛̣𝑐 𝑝ℎ𝑒́𝑝!\n𝐺𝑜̃ /start 𝑑𝑒̂̉ 𝑥𝑒𝑚 𝑑𝑎𝑛ℎ 𝑠𝑎́𝑐ℎ 𝑙𝑒̣̂𝑛ℎ</blockquote>",
                        parse_mode=ParseMode.HTML
                    )
                    asyncio.create_task(tu_dong_xoa_tin_nhan(phan_hoi.chat.id, phan_hoi.message_id, 8))
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"Lỗi trong xu_ly_tin_nhan_khong_phai_lenh: {e}")

async def periodic_cleanup():
    cleanup_interval = 3600  # 1 giờ - giảm tần suất cleanup
    process_cleanup_interval = 1800  # 30 phút - cleanup processes cũ
    last_process_cleanup = 0

    while True:
        try:
            await asyncio.sleep(cleanup_interval)

            start_time = time.time()
            logger.info("🧹 Bắt đầu dọn dẹp định kỳ...")

            # 1. Cache cleanup
            try:
                cleanup_old_cache()
                logger.info("Dọn cache hoàn thành")
            except Exception as e:
                logger.error(f"Lỗi dọn cache: {e}")
            try:
                await cleanup_full_status_safe()
            except Exception as e:
                logger.error(f"Lỗi dọn FULL_STATUS: {e}")

            # 3. Cleanup processes cũ (mỗi 30 phút)
            current_time = time.time()
            if current_time - last_process_cleanup > process_cleanup_interval:
                try:
                    await cleanup_old_processes()
                    last_process_cleanup = current_time
                except Exception as e:
                    logger.error(f"Lỗi cleanup processes cũ: {e}")

            # 4. Force garbage collection
            try:
                import gc
                collected = gc.collect()
                if collected > 0:
                    logger.info(f"🗑️ Thu gom {collected} objects")
            except Exception as e:
                logger.error(f"Lỗi garbage collection: {e}")

            # 5. Kiểm tra memory usage
            try:
                import psutil
                process = psutil.Process()
                memory_mb = process.memory_info().rss / 1024 / 1024
                cpu_percent = process.cpu_percent()
                logger.info(f"📊 Memory: {memory_mb:.1f}MB, CPU: {cpu_percent:.1f}%")

                # Cảnh báo nếu memory quá cao
                if memory_mb > 500:
                    logger.warning(f"⚠️ Memory cao: {memory_mb:.1f}MB")

            except ImportError:
                logger.debug("psutil không có, bỏ qua monitor memory")
            except Exception as e:
                logger.error(f"Lỗi check memory: {e}")

            duration = time.time() - start_time
            logger.info(f"Dọn dẹp hoàn thành trong {duration:.1f}s")

        except asyncio.CancelledError:
            logger.info("🛑 Cleanup task bị hủy")
            break
        except Exception as e:
            logger.error(f"Lỗi periodic cleanup: {e}", exc_info=True)

async def cleanup_old_processes():
    """Dọn dẹp processes cũ chạy quá 6 giờ"""
    logger.info("🔍 Kiểm tra processes cũ...")

    old_processes = []
    current_time = time.time()

    try:
        for proc in psutil.process_iter(['pid', 'cmdline', 'create_time', 'name']):
            try:
                proc_info = proc.info
                if not proc_info['cmdline']:
                    continue

                cmdline = ' '.join(proc_info['cmdline'])
                create_time = proc_info.get('create_time', 0)

                # Kiểm tra process Python liên quan
                is_target = (
                    ('python' in proc_info['name'].lower() or 'python' in cmdline.lower()) and
                    any(script in cmdline for script in [
                        'spam_', 'sms_', 'vip_', 'call', 'tcp.py', 'tt.py',
                        'ngl.py', 'pro24h.py', 'vip11122.py', 'master222.py'
                    ])
                )

                if is_target and create_time:
                    age = current_time - create_time
                    if age > 21600:  # 6 giờ
                        old_processes.append({
                            'pid': proc_info['pid'],
                            'age_hours': age / 3600,
                            'cmdline': cmdline[:100]
                        })

            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if old_processes:
            for proc_data in old_processes:
                logger.warning(f"  PID {proc_data['pid']} ({proc_data['age_hours']:.1f}h): {proc_data['cmdline']}")

            killed = tat_tien_trinh_dong_bo("python.*lenh")
            if killed:
                logger.info(f"Đã dọn dẹp processes cũ")
            else:
                logger.warning("⚠️ Không thể dọn dẹp một số processes cũ")
        else:
            logger.info("Không có processes cũ cần dọn dẹp")

    except Exception as e:
        logger.error(f"Lỗi cleanup_old_processes: {e}")

async def cleanup_full_status_safe():
    """Dọn dẹp FULL_STATUS an toàn với batch processing"""
    if 'FULL_STATUS' not in globals() or 'FULL_LOCK' not in globals():
        return

    try:
        current_time = time.time()
        keys_to_remove = []
        with FULL_LOCK:
            keys_to_remove = [k for k, v in FULL_STATUS.items() 
                             if v < current_time - 3600]  # 1 giờ buffer
        if keys_to_remove:
            batch_size = 50
            removed_total = 0

            for i in range(0, len(keys_to_remove), batch_size):
                batch = keys_to_remove[i:i + batch_size]
                with FULL_LOCK:
                    for key in batch:
                        FULL_STATUS.pop(key, None)
                        removed_total += 1

                # Nghỉ giữa các batch
                if i + batch_size < len(keys_to_remove):
                    await asyncio.sleep(0.01)

            logger.info(f"🧹 Đã xóa {removed_total} entries cũ từ FULL_STATUS")

    except Exception as e:
        logger.error(f"Lỗi cleanup FULL_STATUS: {e}")

async def main():
    """Hàm chính với retry mechanism cải tiến"""
    if not MA_TOKEN_BOT or MA_TOKEN_BOT == "YOUR_BOT_TOKEN_HERE":
        logger.error("Token bot không hợp lệ!")
        return

    max_retries = 10
    retry_delay = 2
    cleanup_task = None

    for attempt in range(max_retries):
        try:
            logger.info(f"🚀 Khởi động bot - Lần thử {attempt + 1}/{max_retries}")

            # Khởi tạo database
            try:
                khoi_tao_database()
                khoi_tao_admin_mac_dinh()
                logger.info("Database khởi tạo thành công")
            except Exception as e:
                logger.error(f"Lỗi khởi tạo database: {e}")
                raise

            dp = Dispatcher()
            router = create_router()
            dp.include_router(router)

            bot_info = None
            for connect_attempt in range(3):
                try:
                    logger.info(f"🔌 Thử kết nối lần {connect_attempt + 1}/3...")
                    bot_info = await asyncio.wait_for(bot.get_me(), timeout=30.0)
                    logger.info(f"Bot kết nối thành công: @{bot_info.username}")
                    break
                except (asyncio.TimeoutError, TelegramNetworkError) as e:
                    logger.error(f"Lỗi kết nối lần {connect_attempt + 1}: {e}")
                    if connect_attempt < 2:
                        await asyncio.sleep(5)
                        continue
                    else:
                        raise Exception("Không thể kết nối đến Telegram sau 3 lần thử")

            if not bot_info:
                raise Exception("Không thể lấy thông tin bot")

            # Khởi động cleanup task
            cleanup_task = asyncio.create_task(periodic_cleanup())
            logger.info("🔄 Bắt đầu polling...")
            try:
                await dp.start_polling(
                    bot,
                    drop_pending_updates=True,  # Bỏ qua tin nhắn cũ
                    timeout=20,                 # Timeout hợp lý
                    relax=0.1,                  # Delay ít giữa requests  
                    fast=True,                  # Bật fast mode
                    handle_as_tasks=True,       # Xử lý concurrent
                    allowed_updates=['message', 'callback_query']  # Chỉ nhận cần thiết
                )
            finally:
                # Đảm bảo cleanup task được hủy
                if cleanup_task and not cleanup_task.done():
                    cleanup_task.cancel()
                    try:
                        await cleanup_task
                    except asyncio.CancelledError:
                        pass
                    logger.info(" Cleanup task đã dừng")

            logger.info("Bot chạy thành công và kết thúc bình thường!")
            break

        except KeyboardInterrupt:
            logger.info("⏹️ Bot bị dừng bởi người dùng")
            break

        except (TelegramNetworkError, asyncio.TimeoutError) as e:
            logger.error(f"🌐 Lỗi mạng lần {attempt + 1}: {e}")
            if attempt < max_retries - 1:
                wait_time = min(retry_delay * (attempt + 1), 60)
                logger.info(f"⏳ Chờ {wait_time}s trước khi thử lại...")
                await asyncio.sleep(wait_time)
                continue
            else:
                logger.error("Hết số lần thử kết nối mạng")
                break

        except Exception as e:
            logger.error(f"💥 Lỗi không mong muốn lần {attempt + 1}: {e}", exc_info=True)
            if attempt < max_retries - 1:
                wait_time = min(retry_delay * 2, 30)
                logger.info(f"⏳ Chờ {wait_time}s trước khi restart...")
                await asyncio.sleep(wait_time)
                retry_delay = min(retry_delay * 1.5, 30)
                continue
            else:
                logger.error("Đã hết số lần thử, dừng bot")
                break
        finally:
            # Cleanup nếu có lỗi
            if cleanup_task and not cleanup_task.done():
                cleanup_task.cancel()
                try:
                    await cleanup_task
                except asyncio.CancelledError:
                    pass

def chay_bot():
    import signal
    atexit.register(lambda: tat_tien_trinh_dong_bo("python.*lenh"))

    def signal_handler(signum, frame):
        signal_name = {
            signal.SIGINT: "SIGINT (Ctrl+C)",
            signal.SIGTERM: "SIGTERM (Kill)",
            signal.SIGHUP: "SIGHUP (Hangup)"
        }.get(signum, f"Signal {signum}")

        logger.info(f" Nhận {signal_name}, đang dọn dẹp...")
        try:
            tat_tien_trinh_dong_bo("python.*lenh")
            logger.info("Cleanup hoàn thành")
        except Exception as e:
            logger.error(f"Lỗi cleanup: {e}")
        exit(0)

    for sig in [signal.SIGINT, signal.SIGTERM]:
        if hasattr(signal, sig.name):  # Kiểm tra signal có tồn tại không
            signal.signal(sig, signal_handler)

    # Thêm SIGHUP nếu không phải Windows
    if os.name != 'nt' and hasattr(signal, 'SIGHUP'):
        signal.signal(signal.SIGHUP, signal_handler)

    max_restarts = 10  # Giảm từ 50 xuống 10
    restart_count = 0
    consecutive_failures = 0
    start_time = time.time()

    logger.info("🤖 Khởi động hệ thống bot...")

    while restart_count < max_restarts:
        bot_start_time = time.time()
        try:
            if os.name == 'nt':
                asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

            asyncio.run(main())
            logger.info(" Bot kết thúc bình thường")
            break

        except KeyboardInterrupt:
            logger.info("⏹️ Bot bị dừng bởi người dùng")
            break

        except Exception as e:
            runtime = time.time() - bot_start_time
            total_runtime = time.time() - start_time

            if runtime > 3600:
                consecutive_failures = 0
                logger.info("🔄 Reset failure count do bot chạy lâu")
            else:
                consecutive_failures += 1

            logger.error(f"💥 Bot crash sau {runtime:.1f}s (tổng: {total_runtime/3600:.1f}h): {e}")
            restart_count += 1

            try:
                tat_tien_trinh_dong_bo("python.*lenh")
            except Exception as cleanup_error:
                logger.error(f"Lỗi cleanup: {cleanup_error}")

            if restart_count < max_restarts:
                base_wait = min(consecutive_failures * 10, 300)  # Tối đa 5 phút
                actual_wait = min(base_wait, 60)  # Giới hạn 1 phút cho lần đầu

                logger.info(f"⏳ Chờ {actual_wait}s trước khi restart (lần {restart_count}/{max_restarts})")
                time.sleep(actual_wait)
            else:
                logger.error("Đã đạt giới hạn restart, dừng bot")
                break

    total_runtime = time.time() - start_time
    logger.info(f"🏁 Bot dừng hoàn toàn sau {total_runtime/3600:.1f} giờ")

if __name__ == "__main__":
    chay_bot()
