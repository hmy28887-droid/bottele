import requests
import concurrent.futures
import time
import os
from pathlib import Path

CONFIG = {
    "check-site": "https://www.google.com",
    "proxy-type": "http",
    "http_threads": 1000,
    "headers": {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"
    },
    "print_ips": {
        "enabled": True,
        "display-ip-info": True
    },
    "timeout": {
        "http_timeout": 8,
        "socks4_timeout": 8,
        "socks5_timeout": 8
    }
}

PROXY_SOURCES = [
    "https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=2000&country=VN",
    "https://www.proxy-list.download/api/v1/get?type=http&country=VN",
    "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
    "https://www.sslproxies.org/",
    "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "https://www.proxy-list.download/api/v1/get?type=http",
    "https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=5000&country=all&ssl=yes&anonymity=all",
    "https://api.proxyscrape.com/?request=displayproxies&proxytype=socks5&timeout=5000&country=all&ssl=yes&anonymity=all",
    "https://proxylist.geonode.com/api/proxy-list?limit=50&page=1&sort_by=lastChecked&sort_type=desc",
    "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
    "https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
    "https://raw.githubusercontent.com/almroot/proxylist/master/list.txt",
    "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/http.txt",
    "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt",
    "https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
    "https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt",
    "https://raw.githubusercontent.com/shiftytr/proxy-list/master/proxy.txt",
    "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
    "https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/https.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt",
    "https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt",
    "https://raw.githubusercontent.com/aslisk/proxyhttps/main/https.txt",
    "https://raw.githubusercontent.com/hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt",
    "https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt",
    "https://api.proxyscrape.com/?request=displayproxies&proxytype=http",
    "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/cnfree.txt",
    "https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt",
    "https://raw.githubusercontent.com/saisuiu/uiu/main/free.txt",
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
    "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
    "https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt",
    "https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt",
    "https://sunny9577.github.io/proxy-scraper/proxies.txt",
    "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
    "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt",
    "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt",
    "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/http.txt",
    "https://api.proxyscrape.com/?request=displayproxies&proxytype=https",
    "https://proxyspace.pro/https.txt",
    "https://proxyspace.pro/http.txt",
    "https://firet.io/firetx_retro/datacanthiet/proxies.txt",
    "https://www.proxy-list.download/api/v1/get?type=http",
    "https://www.proxy-list.download/api/v1/get?type=https",
    "https://api.openproxylist.xyz/http.txt",
    "https://openproxylist.xyz/http.txt",
    "https://proxy-spider.com/api/proxies.example.txt"
]

# CẤU HÌNH CÁC FILE TXT PROXY CỦA BẠN
PROXY_FILES = [
    "zz.",      # Thay bằng tên file thực tế của bạn
    "check.txt",      # Có thể có nhiều file
    "zmap.txt",  # Thêm bao nhiêu file cũng được
]

OUTPUT_FILE = "proxies.txt"

def fetch_proxies_from_web():
    """Lấy proxy từ các nguồn online"""
    proxies = set()
    print("[*] Đang tải proxy từ các trang web...")
    
    for url in PROXY_SOURCES:
        try:
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                initial_count = len(proxies)
                for line in r.text.splitlines():
                    line = line.strip()
                    if ":" in line and line.count(":") == 1:  # Format IP:PORT
                        proxies.add(line)
                new_count = len(proxies) - initial_count
                print(f"[+] Lấy từ {url} → +{new_count} proxy")
        except Exception as e:
            print(f"[!] Lỗi khi lấy {url}: {e}")
    
    return proxies

def load_proxies_from_files():
    """Đọc proxy từ các file txt"""
    proxies = set()
    print("[*] Đang đọc proxy từ các file txt...")
    
    for file_path in PROXY_FILES:
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    initial_count = len(proxies)
                    for line in f:
                        line = line.strip()
                        # Bỏ qua dòng comment và dòng trống
                        if line and not line.startswith('#') and ':' in line:
                            # Hỗ trợ format: IP:PORT hoặc protocol://IP:PORT
                            if line.startswith('http://'):
                                line = line[7:]  # Bỏ http://
                            elif line.startswith('https://'):
                                line = line[8:]  # Bỏ https://
                            
                            if line.count(':') == 1:  # Đảm bảo format IP:PORT
                                proxies.add(line)
                    
                    new_count = len(proxies) - initial_count
                    print(f"[+] Đọc từ {file_path} → +{new_count} proxy")
                    
            except Exception as e:
                print(f"[!] Lỗi khi đọc {file_path}: {e}")
        else:
            print(f"[!] File không tồn tại: {file_path}")
    
    return proxies

def fetch_all_proxies():

    web_proxies = fetch_proxies_from_web()
    print(f"{len(web_proxies)}")
    
    # Lấy từ file
    file_proxies = load_proxies_from_files()
    print(f"{len(file_proxies)}")
    
    # Kết hợp (set tự động loại bỏ duplicate)
    all_proxies = web_proxies.union(file_proxies)
    print(f"[*] Tổng proxy (sau khi loại bỏ trùng lặp): {len(all_proxies)}")
    
    return list(all_proxies)

def get_ip_info(proxy):
    try:
        proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        r = requests.get("https://ipinfo.io/json", proxies=proxies, headers=CONFIG["headers"], timeout=CONFIG["timeout"]["http_timeout"])
        if r.status_code == 200:
            return r.json()
    except:
        return None
        
def check_proxy(proxy):
    try:
        proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        r = requests.get(CONFIG["check-site"], proxies=proxies, headers=CONFIG["headers"], timeout=CONFIG["timeout"]["http_timeout"])
        if r.status_code == 200:
            # Chỉ in proxy sống
            print(f"[Proxy OK] {proxy}")
            return proxy
    except:
        pass
    return None

def save_results(alive_proxies):
    """Lưu kết quả vào file"""
    # Lưu proxy sống
    with open(OUTPUT_FILE, "w") as f:
        for proxy in alive_proxies:
            f.write(proxy + "\n")
    print(f"[*] Đã lưu {len(alive_proxies)} proxy sống vào {OUTPUT_FILE}")

def main():
    print("="*60)
    print("PROXY CHECKER - Kết hợp Online + File TXT")
    print("="*60)
    
    # Thu thập từ tất cả nguồn
    proxy_list = fetch_all_proxies()
    
    if not proxy_list:
        print("[!] Không có proxy nào để kiểm tra.")
        return

    print(f"\n[*] Bắt đầu kiểm tra {len(proxy_list)} proxy với {CONFIG['http_threads']} threads...")
    start_time = time.time()
    
    alive_list = []
    dead_count = 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=CONFIG["http_threads"]) as executor:
        # Submit all tasks
        future_to_proxy = {executor.submit(check_proxy, proxy): proxy for proxy in proxy_list}
        
        # Process results as they complete
        for future in concurrent.futures.as_completed(future_to_proxy):
            proxy = future_to_proxy[future]
            try:
                result = future.result()
                if result:
                    alive_list.append(result)
                else:
                    dead_count += 1
                    
                # Progress update mỗi 50 proxy
                total_checked = len(alive_list) + dead_count
                if total_checked % 50 == 0:
                    print(f"[Progress] Đã check: {total_checked}/{len(proxy_list)} - Sống: {len(alive_list)} - Chết: {dead_count}")
                    
            except Exception as e:
                dead_count += 1
                print(f"[Error] Lỗi khi check {proxy}: {e}")

    end_time = time.time()
    duration = end_time - start_time
    
    # Lưu kết quả
    save_results(alive_list)
    
    # Thống kê cuối
    print("\n" + "="*60)
    print("KẾT QUẢ CUỐI CÙNG")
    print("="*60)
    print(f"Tổng proxy kiểm tra: {len(proxy_list)}")
    print(f"Proxy sống: {len(alive_list)}")
    print(f"Proxy chết: {dead_count}")
    print(f"Tỷ lệ sống: {len(alive_list)/len(proxy_list)*100:.1f}%")
    print(f"Thời gian: {duration:.1f} giây")
    print(f"Tốc độ: {len(proxy_list)/duration:.1f} proxy/giây")
    print("="*60)

if __name__ == "__main__":
    main()